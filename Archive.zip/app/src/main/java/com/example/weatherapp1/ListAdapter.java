package com.example.weatherapp1;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ListAdapter extends BaseAdapter {
    Activity activity;
    ArrayList<MainWeatherClass> weatherList;
    String url;

    public ListAdapter(Activity activity, ArrayList<MainWeatherClass> weatherList) {
        this.activity = activity;
        this.weatherList = weatherList;
    }

    @Override
    public int getCount() {
        return weatherList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public class ViewHolder {
        TextView cityField, detailsField, currentTemperatureField, humidity_field, pressure_field, updatedField;
        Button deleteButton;
        ListView lv;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        LayoutInflater inflater = activity.getLayoutInflater();
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.adapter_part, null);
            holder = new ViewHolder();
            holder.cityField = (TextView) convertView.findViewById(R.id.cityField);
            holder.detailsField = (TextView) convertView.findViewById(R.id.detailField);
            holder.currentTemperatureField = (TextView) convertView.findViewById(R.id.tempField);
            holder.humidity_field = (TextView) convertView.findViewById(R.id.humidField);
            holder.pressure_field = (TextView) convertView.findViewById(R.id.pressureField);
            holder.updatedField = (TextView) convertView.findViewById(R.id.updateField);
            holder.deleteButton = (Button) convertView.findViewById(R.id.deleteBTN);
            holder.lv = (ListView) convertView.findViewById(R.id.weatherLV);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        for(int i = 0; i < weatherList.size(); i++) {
            DateFormat df = DateFormat.getDateTimeInstance();

            Log.d("Network", "getView: " + weatherList.toString());
            holder.cityField.setText("City: " + weatherList.get(i).getName());
            holder.detailsField.setText("Visibility: " + weatherList.get(i).getVisibility() + "m");
            holder.currentTemperatureField.setText("Temperature: " + weatherList.get(i).getOther().getTemp() + "C");
            holder.humidity_field.setText("Humidity: " + weatherList.get(i).getOther().getHumidity() + "g/m3");
            holder.pressure_field.setText("Pressure: " + weatherList.get(i).getOther().getPressure() + "Pa");
            holder.updatedField.setText("Wind speed:" + weatherList.get(i).getWind().getSpeed() + "m/s");
        }
        return convertView;
    }
}
